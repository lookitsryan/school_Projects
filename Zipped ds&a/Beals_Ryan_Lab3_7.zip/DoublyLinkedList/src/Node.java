/**
 * Class representing nodes in singly linked list
 * @author Ryan
 *
 */
public class Node<E> {
	
	/**
	 * The data contained in this node
	 */
	private E data;
	
	/**
	 * The reference to the next node in the list
	 */
	private Node<E> next;
	
	/**
	 * The reference to the next node in the list
	 */
	private Node<E> prev;
	
	/**
	 * Creates a new node for the list with the given data and link to the next node
	 * @param data the data kept in this node
	 * @param nextNode the next node in the list
	 */
	Node(E data, Node<E> prevNode, Node<E> nextNode){
		this.data = data;
		this.next = nextNode;
		this.prev = prevNode;
	}
	
	/**
	 * Returns the data associated with this node
	 * @return this node's data
	 */
	E getData() {return this.data;}
	
	/**
	 * Returns the next node in the list
	 * @return the node that follows this one in the list
	 */
	Node<E> getNext(){return this.next;}
	
	/**
	 * Sets the data for this node
	 * @param data data to replace this node's data with
	 */
	void setData(E data) {this.data = data;}
	
	/**
	 * Sets the next node in the list
	 * @param next next node in the list
	 */
	void setNext(Node<E> next) {this.next = next;}
	
	/**
	 * Sets the next node in the list
	 * @param next next node in the list
	 */
	Node<E> getPrev() {return this.prev;}
	
	/**
	 * Sets the next node in the list
	 * @param next next node in the list
	 */
	void setPrev(Node<E> prev) {this.prev = prev;}
}
