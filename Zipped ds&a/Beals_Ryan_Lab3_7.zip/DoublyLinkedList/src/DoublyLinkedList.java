import java.util.Iterator;
import java.util.NoSuchElementException;

public class DoublyLinkedList<E> implements Iterable {
	
	/**
	 * Node at the beginning of the list
	 */
	private Node<E> head;
	
	/**
	 * Node at the end of the list
	 */
	private Node<E> tail;
	
	/**
	 * Size of the list
	 */
	private int size;
	
	/**
	 * Constructor for list, sets head to null, tail to null, and size to 0.
	 */
	DoublyLinkedList(){
		this.head = null;
		this.tail = null;
		size = 0;
	}
	
	/**
	 * Method to add E element to the end of the list
	 * @param element E to add to DoublyLinkedList
	 */
	void add(E element) {
		Node<E> newNode = new Node<E>(element, null, null);
		size++;
		if(this.head == null) { //If the list is empty, add the new element to the head
			this.head = newNode;
			this.tail = this.head;
		}else {
			if(head.getNext() == null) { //If the list is one Node long, add element to head and set tail to element.
				this.head.setNext(newNode);
				this.tail = newNode;
				tail.setPrev(this.head);
			}else {
				this.tail.setNext(newNode);
				newNode.setPrev(this.tail);
				this.tail = newNode;
			}
		}
	}
	
	/**
	 * Method to add E element at int index
	 * @param element E to add to DoublyLinkedList
	 * @param index index at which to add element
	 */
	void add(E element, int index) {
		Node<E> newNode = new Node<E>(element, null, null);
		if(this.size < index) { //If index is out of bounds...
			throw new IndexOutOfBoundsException();
		}
		
		if(index == this.size) { //If the index to add the element is at size, the new node should go after the current tail and replace it as the tail
			Node<E> currentNode = this.tail;
			currentNode.setNext(newNode);
			newNode.setPrev(currentNode);
			this.tail = newNode;
			this.size++;
			return; //Ensures no duplicate adds
		}else if(index == 0) { //If the index to add the element is at 0, the new node should go before the current head and replace it as the head
			if(head == null) {
				this.head = newNode;
				this.tail = this.head;
				this.size++;
				return;
			}else {
				Node<E> currentNode = this.head;
				currentNode.setPrev(newNode);
				newNode.setNext(currentNode);
				this.head = newNode;
				this.size++;
				return; //Ensures no duplicate adds
			}
		}
		
		if(index > this.size/2) { //If the index to add the element is at greater than half of the size...
			Node<E> currentNode = this.tail;
			for(int i = this.size; i > index; i--) { //Go to Node at the index of "index", loop backwards to save running time
				currentNode = currentNode.getPrev();
			}
			//Place newNode between currentNode and the node before currentNode
			currentNode.getPrev().setNext(newNode);
			newNode.setPrev(currentNode.getPrev());
			newNode.setNext(currentNode);
			currentNode.setPrev(newNode);
			this.size++;
			return; //Ensures no duplicate adds
		}else if(index <= this.size/2) {
			Node<E> currentNode = this.head;
			for(int i = 0; i < index; i++) {
				currentNode = currentNode.getNext();
			}
			currentNode.getPrev().setNext(newNode);
			newNode.setPrev(currentNode.getPrev());
			newNode.setNext(currentNode);
			currentNode.setPrev(newNode);
			this.size++;
			return; //Ensures no duplicate adds
		}
	}
	
	/**
	 * Remove element at index
	 * @param index int at which to remove
	 * @return removed element
	 */
	E remove(int index){
		Node<E> currentNode;
		if(this.size <= index) { //If index is out of bounds...
			throw new IndexOutOfBoundsException();
		}
		
		if(index == this.size-1) { //If the index to add the element is at size, the new node should go after the current tail and replace it as the tail
			currentNode = tail;
			tail = currentNode.getPrev();
			currentNode.getPrev().setNext(null);
			this.size--;
			return currentNode.getData();
		}else if(index == 0) { //If the index to add the element is at 0, the new node should go before the current head and replace it as the head
			currentNode = this.head;
			this.head = currentNode.getNext();
			currentNode.getNext().setPrev(null);
			this.size--;
			return currentNode.getData();
		}if(index > this.size/2) { //If the index to add the element is at greater than half of the size...
			currentNode = this.tail;
			for(int i = this.size; i > index; i--) { //Go to Node at the index of "index", loop backwards to save running time
				currentNode = currentNode.getPrev();
			}
			//Remove the element by setting the previous element to the next element and vice-versa
			currentNode.getPrev().setNext(currentNode.getNext());
			currentNode.getNext().setPrev(currentNode.getPrev());
			this.size--;
			return currentNode.getData();
		}else if(index <= this.size/2) { //If the index to add element is less than half...
			currentNode = this.head;
			for(int i = 0; i < index; i++) {
				currentNode = currentNode.getNext();
			}
			currentNode.getPrev().setNext(currentNode.getNext());
			currentNode.getNext().setPrev(currentNode.getPrev());
			this.size--;
			return currentNode.getData();
		}
		return null;
	}
	
	/**
	 * Removes element at the end of list
	 * @return removed element
	 */
	E remove() {
		if(this.tail == null) { //If the list is empty, throw NoSuchElementException
			throw new NoSuchElementException();
		}
		Node<E> currentNode = this.tail;
		if(currentNode.getPrev() == null) { //If the length of the list is 1, then set the tail to null
			this.tail = null;
			this.size--;
		}else { //Otherwise, move the tail back 1 element
			this.tail = currentNode.getPrev();
			this.tail.setNext(null);
			this.size--;
		}
		return currentNode.getData();
	}
	
	/**
	 * Replaces the data of the element at index with "element"
	 * @param element Data to put into the list
	 * @param index Index at which to replace
	 * @return element that was replaced
	 */
	E set(E element, int index) {
		Node<E> currentNode;
		if(this.size <= index) { //If index is out of bounds...
			throw new IndexOutOfBoundsException();
		}
		if(index > this.size/2) { //If the index to add the element is at greater than half of the size...
			currentNode = this.tail;
			for(int i = this.size; i > index; i--) { //Go to Node at the index of "index", loop backwards to save running time
				currentNode = currentNode.getPrev();
			}
			//Overwrite currentNode, but keep currentNode in temp for returning
			Node<E> temp = currentNode;
			currentNode.setData(element);
			return temp.getData(); //Ensures no duplicate adds
		}else if(index <= this.size/2) {
			currentNode = this.head;
			for(int i = 0; i < index; i++) { //Go to Node at index of "index"
				currentNode = currentNode.getNext();
			}
			//Overwrite currentNode, but keep currentNode in temp for returning
			Node<E> temp = currentNode;
			currentNode.setData(element);
			return temp.getData(); //Ensures no duplicate adds
		}
		return null;
	}
	
	/**
	 * @return String with elements in brackets
	 */
	public String toString() {
		String str = "";
		str += "[";
		Node<E> currentNode = head;
		for(int i = 0; i < size; i++) {
			str+= currentNode.getData();
			currentNode = currentNode.getNext();
			if(i != size-1) {
				str+= ", ";
			}
		}
		str+="]";
		return str;
	}

	/**
	 * Iterator for client
	 */
	@Override
	public Iterator<E> iterator() {
		return new DLLIterator();
	}
	
	/**
	 * Inner class: DLLIterator
	 * @author student
	 */
	public class DLLIterator implements Iterator<E>{
		//Node that was already returned by next
		private Node<E> currentNode;
		
		/**
		 * 
		 */
		private int index;
		/**
		 * Constructor for DLLIterator
		 */
		DLLIterator() {
			this.currentNode = null;
			this.index = -1;
		}
		
		
		public boolean hasNext() {
			return this.currentNode == null ? head != null : this.currentNode.getNext() == null ? true : false;
		}

		/**
		 * Iterate to next element in list
		 * @return next element
		 */
		public E next() {
			if(!hasNext()) {
				throw new NoSuchElementException();
			}
			//If the currentNode is null, then set it to head
			if(currentNode == null) {
				this.currentNode = head;
				this.index++;
				return this.currentNode.getData();
			}
			this.index++;
			currentNode = currentNode.getNext();
			return currentNode.getData();
		}
		
		/**
		 * Remove last returned element
		 */
		public void remove() {
			if(index == -1) {
				throw new IllegalStateException();
			}
			currentNode.getPrev().setNext(currentNode.getNext());
			currentNode.getNext().setPrev(currentNode.getPrev());
			DoublyLinkedList.this.size--;
		}
		

		
	}
}
