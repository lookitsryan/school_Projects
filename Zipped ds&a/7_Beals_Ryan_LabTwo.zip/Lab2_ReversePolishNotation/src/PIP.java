import java.util.Stack;

public class PIP {
	
	/**
	 * Evaluates a postfix expression
	 * @param postfix Postfix expression separated with spaces
	 * @return int returned by postfix expression
	 */
	public static int evaluatePostfix(String postfix) {
		final Stack<Integer> stack = new Stack<Integer>();
		String delims = " ";
		String[] tokens = postfix.split(delims); //Splits string
		for(int i = 0; i < tokens.length; i++) {
			if(tokens[i].charAt(0) == 37 || tokens[i].charAt(0) == 42 || tokens[i].charAt(0) == 43 || 
					tokens[i].charAt(0) == 45 || tokens[i].charAt(0) == 47) { //checks for operators
				char operator = tokens[i].charAt(0);
				if(stack.size() >= 2) { //If the stack is bigger than or equal to 2, evaluate the numbers inside
					int second = stack.pop();
					int first = stack.pop();
					stack.push(evaluateExpression(first, second, operator));
				}else {
					throw new IllegalArgumentException("Invalid postfix expression.");
				}
			}else {
				stack.push(Integer.parseInt(tokens[i]));
			}
		}
		if(stack.size() > 1) {
			throw new IllegalArgumentException("Invalid postfix expression.");
		}else if(stack.size() == 0) {
			throw new IllegalArgumentException("Invalid postfix expression.");
		}else {
			return stack.peek();
		}
	}
	
	/**
	 * Helper method to evaluate the expression given by postfix
	 * @param first First operand
	 * @param second Second operand
	 * @param operator Operator to evaluate the two operands
	 * @return Evaluated expression
	 */
	public static int evaluateExpression(int first, int second, char operator) {
		switch(operator) {
	    case '+':
	        return first + second;
	    case '-':
	      	return first - second;
	    case '*':
	    	    return first * second;
	    case '/':
	    	    if(second == 0) {
	    	    	    throw new IllegalArgumentException("Invalid postfix expression.");
	    	    }else {
	    	    	    return first/second;
	    	    }
	    case '&':
	    	    return first & second;
		}
		return 0;
	}
	
	/**
	 * Converts an infix expression separated with spaces to a postfix expression
	 * @param infix Infix expression separated with spaces 
	 * @return Postfix expression
	 */
	public static String infixToPostfix(String infix) {
		String postfix = "";
		Stack<Character> stack = new Stack<Character>();
		String delims = " ";
		String[] tokens = infix.split(delims);
		int numOperators = 0;
		int numOperands = 0;
		for(int i = 0; i < tokens.length; i++) {
			System.out.println(postfix);
			System.out.println(tokens[i]);
			if(tokens[i].charAt(0) == 37 || tokens[i].charAt(0) == 42 || tokens[i].charAt(0) == 43 || 
					tokens[i].charAt(0) == 45 || tokens[i].charAt(0) == 47 || tokens[i].charAt(0) == 40
					|| tokens[i].charAt(0) == 41) {
				char operator = tokens[i].charAt(0);
				int num = numForOperator(operator);
				if(stack.isEmpty()) {
					if(numForOperator(operator) == 3){
						throw new IllegalArgumentException("Invalid infix expression.");
					}
					stack.push(operator);
				}else {
					if(num == 3) {
						while(numForOperator(stack.peek()) != 2 && stack.size() > 0){
							postfix += stack.pop() + " ";
							numOperators++;
						}
						if(stack.size() == 0){
							throw new IllegalArgumentException("Invalid infix expression.");
						}else{
							stack.pop();
						}
					}else{
						if(numForOperator(stack.peek()) == 2 || numForOperator(stack.peek()) < num){
							stack.push(operator);
						}else{
						    while(stack.size() > 0 && numForOperator(stack.peek()) >= num){
						    	if(numForOperator(stack.peek()) == 2){
						    		break;
						    	}else{
						    		postfix += stack.pop() + " ";
						    		numOperators++;
						    	}
						    }
						    stack.push(operator);
						}

					}
				} 
			}else{
				postfix += tokens[i] + " ";
				numOperands++;
			}
		}
		for(int j = 0; j <= stack.size(); j++){
			postfix += stack.pop() + " ";
			numOperators++;
		}
		if(numOperands - numOperators != 1){
			throw new IllegalArgumentException("Invalid infix expression.");
		}
		return postfix;
	}
	
	/**
	 * Returns arbitrary int value for each operator, used to evaluate precedence
	 * @param c
	 * @return
	 */
	public static int numForOperator(char operator) {
		switch(operator) {
	    case '+':
	        return 0;
	    case '-':
	      	return 0;
	    case '*':
	    	return 1;
	    case '/':
	    	return 1;
	    case '&':
	    	return 1;
	    case '(':
	    	return 2;
	    case ')':
	    	return 3;
		}
		return -1;
	}
	
}
