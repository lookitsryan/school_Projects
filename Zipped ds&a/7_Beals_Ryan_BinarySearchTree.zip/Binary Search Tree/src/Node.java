/**
 * Class representing nodes in singly linked list
 * @author Ryan
 *
 */
public class Node<E extends Comparable<E>> implements Comparable<E>{
	
	/**
	 * The data contained in this node
	 */
	private E data;
	
	/**
	 * The reference to the next node in the list
	 */
	private Node<E> leftNode;
	
	/**
	 * The reference to the next node in the list
	 */
	private Node<E> rightNode;
	
	/**
	 * Creates a new node for the list with the given data and link to the next node
	 * @param data the data kept in this node
	 * @param nextNode the next node in the list
	 */
	Node(E data, Node<E> left, Node<E> right){
		this.data = data;
		this.leftNode = left;
		this.rightNode = right;
	}
	
	/**
	 * Returns the data associated with this node
	 * @return this node's data
	 */
	E getData() {return this.data;}
	
	/**
	 * Sets the data for this node
	 * @param data data to replace this node's data with
	 */
	void setData(E data) {this.data = data;}
	
	/**
	 * Returns the next node in the list
	 * @return the node that follows this one in the list
	 */
	Node<E> getRight(){return this.rightNode;}
	
	/**
	 * Sets the next node in the list
	 * @param next next node in the list
	 */
	void setRight(Node<E> right) {this.rightNode = right;}
	
	/**
	 * Sets the next node in the list
	 * @param next next node in the list
	 */
	Node<E> getLeft() {return this.leftNode;}
	
	/**
	 * Sets the next node in the list
	 * @param next next node in the list
	 */
	void setLeft(Node<E> left) {this.leftNode = left;}
	
	/**
	 * Method to check if node has children
	 * @return whether or not node has children
	 */
	boolean hasChildren() {return (this.rightNode!=null || this.leftNode!=null);}
	
	/**
	 * Method to check if node has a right node
	 * @return whether or not node has a right node
	 */
	boolean hasRight() {return this.rightNode!=null;}
	
	/**
	 * Method to check if node has left node
	 * @return whether or not node has left node
	 */
	boolean hasLeft() {return this.leftNode!=null;}
	
	/**
	 * toString for Node<E>
	 * @return String containing the data of the Node
	 */
	public String toString(){return this.data.toString();}

	/**
	 * Checks if node has only 1 child
	 * @return true if node has only 1 child
	 */
	boolean hasOnlyChild(){
		return ((this.leftNode != null && this.rightNode == null) || (this.leftNode == null && this.rightNode != null));
	}
	
	/**
	 * Returns only node that this points to
	 * @return only node that this points to
	 */
	Node<E> getOnlyChild(){
		if(this.hasOnlyChild()){
			return this.leftNode != null ? this.leftNode : this.rightNode;
		}else{
			return null;
		}
	}
	
	@Override
	public int compareTo(E compare){
		return this.data.compareTo(compare);
	}
}

