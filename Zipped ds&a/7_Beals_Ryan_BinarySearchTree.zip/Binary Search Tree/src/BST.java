import java.io.File;
import java.util.Scanner;

/**
 * Class for Binary Search Tree
 * @author Ryan
 * @param <E> Type of element in the list
 */
@SuppressWarnings("rawtypes")
public class BST<E extends Comparable<E>>{
	
	/**
	 * Top element of the tree, also known as the root
	 */
	private Node<E> root;
	
	/**
	 * Creates new Binary Search Tree with the root set to null and the size set to 0
	 */
	BST(){
		this.root = null;
	}
	
	/**
	 * Adds element E to the tree
	 * @param element Element to add to the tree
	 */
	@SuppressWarnings("unchecked")
	void add(E element) {
		Node<E> newNode = new Node<E>(element, null, null); //New node 
		if(this.root  == null) { //If there's no root, the list is empty; therefore, set root to newNode
			this.root = newNode; 
			return;
		}else {
			Node<E> nextNode = this.root;
			while(true) {
				if(newNode.compareTo(nextNode.getData()) > 0) { //If nextNode is larger than newNode
					if(nextNode.getRight() == null) { //If there's no right element, add the newNode to the right
						nextNode.setRight(newNode);
						break;
					}else {
						 nextNode = nextNode.getRight();
					}
				}else if(newNode.compareTo(nextNode.getData()) <= 0){ //otherwise
					if(nextNode.getLeft() == null) { //if there's no left element, add the newNode to the left
						nextNode.setLeft(newNode);
						break;
					}else {
						 nextNode = nextNode.getLeft();
					}
				}
			}
		}
		
	}
	
	/**
	 * Helper method for delete to add a node and all of its children to the BST
	 * @param node Node<E> to add to the BST
	 */
	private void addNode(Node<E> node) {
		if(node == null){
			return;
		}else if(node.hasChildren() == false){
			add(node.getData());
			return;
		}else{
			add(node.getData());
			if(node.hasOnlyChild()){
				addNode(node.getOnlyChild());
				return;
			}else{
				addNode(node.getRight());
				addNode(node.getLeft());
				return;
			}
		}
		
	}
	
	/**
	 * Checks tree for value value
	 * @param value value to check for in tree
	 * @return whether or not value is in list
	 */
	boolean contains(E value) {
		Node<E> nextNode = root;
		Node<E> newNode = new Node<E>(value, null, null);
		while(true) {
			if((newNode).compareTo(nextNode.getData()) > 0) { //If nextNode is larger than value being looked for
				if(nextNode.hasRight()) {
					if(nextNode.getRight().getData() == value) {
						return true;
					}else {
						nextNode = nextNode.getRight();
						continue;
					}
				}else {
					return false;
				}
			}else if((newNode).compareTo(nextNode.getData()) <= 0){ //otherwise
				if(nextNode.hasLeft()) {
					if(nextNode.getLeft().getData() == value) {
						return true;
					}else {
						nextNode = nextNode.getLeft();
						continue;
						
					}
				}else {
					return false;
				}
			}
		}
	}
	
	/**
	 * Removes an element from the tree, adds children back to tree
	 * @param value value to be deleted from tree
	 * @return If value was deleted
	 */
	boolean delete(E value) {
		//delNode is the node POINTING TO the value to delete
		if(this.root.getData() == value){
			this.root = null;
		}
		Node<E> parentNode = find(value);
		Node<E> delNode;
		if(parentNode == null) {
			return false;
		}else{
			//If the node has children on the right and the left, check which one is the value
			if(parentNode.hasRight() && parentNode.hasLeft()){
				if(parentNode.getRight().getData() == value){ //if the value is on the right of the parent...
					//Node to delete is to the right
					delNode = parentNode.getRight();
					//Set the pointer of parentNode that's pointing to delNode to null
					parentNode.setRight(null);
					//Add children of delNode
					if(delNode.hasOnlyChild()){
						addNode(delNode.getOnlyChild());
					}else{
						if(delNode.hasChildren()){
							addNode(delNode.getLeft());
							addNode(delNode.getRight());
						}else{
							//do nothing
						}
					}
					return true;
				}else if(parentNode.getLeft().getData() == value){ //if the value is on the left of the parent...
					//Node to delete is to the right
					delNode = parentNode.getLeft();
					//Set the pointer of parentNode that's pointing to delNode to null
					parentNode.setLeft(null);
					//Add children of delNode
					if(delNode.hasOnlyChild()){
						addNode(delNode.getOnlyChild());
					}else{
						if(delNode.hasChildren()){
							addNode(delNode.getLeft());
							addNode(delNode.getRight());
						}else{
							//do nothing
						}
					}
					return true;
				}
			}else if(parentNode.hasLeft()){
				//Node to delete is to the right
				delNode = parentNode.getLeft();
				//Set the pointer of parentNode that's pointing to delNode to null
				parentNode.setLeft(null);
				//Add children of delNode
				if(delNode.hasOnlyChild()){
					addNode(delNode.getOnlyChild());
				}else{
					if(delNode.hasChildren()){
						addNode(delNode.getLeft());
						addNode(delNode.getRight());
					}else{
						//do nothing
					}
				}
				return true;
			}else if(parentNode.hasRight()){ //If the parent node only has a node to the right...
				//Node to delete is to the right
				delNode = parentNode.getRight();
				//Set the pointer of parentNode that's pointing to delNode to null
				parentNode.setRight(null);
				//Add children of delNode
				if(delNode.hasOnlyChild()){
					addNode(delNode.getOnlyChild());
				}else{
					if(delNode.hasChildren()){
						addNode(delNode.getLeft());
						addNode(delNode.getRight());
					}else{
						//do nothing
					}
				}
				return true;
			}else{
				return false;
			}
			return false;
		}
	}
	
	/**
	 * Deletes the entire tree.
	 */
	void delete(){this.root = null;}
	
	/**
	 * Helper method for delete
	 * @param value value to find in the tree
	 * @return Node POINTING TO value
	 */
	private Node<E> find(E value){
		Node<E> currNode = root;
		Node<E> findThis = new Node<E>(value, null, null);
		while(true) {
			if(!(currNode.hasChildren())) {
				return currNode.getData().equals(value) ? currNode : null;
			}else if(findThis.compareTo(currNode.getData()) > 0) { //If value is higher than the value of currNode...
				if(currNode.getRight().getData().equals(value)) { //Check if next element in the tree is value 
					return currNode; //if so, return currNode
				}else {
					currNode = currNode.getRight(); //otherwise, set currNode to the next element in the tree
					continue; //ensures no double sets
				}
			}else if(findThis.compareTo(currNode.getData()) <= 0) { //If value is lower than the value of currNode...
				if(currNode.getLeft().getData().equals(value)) { //Check if next element in the tree is value 
					return currNode; //if so, return currNode
				}else {
					currNode = currNode.getLeft(); //otherwise, set currNode to the next element in the tree
					continue; //ensures no double sets
				}
			}
		}
	}
	
	/**
	 * Counts number of nodes
	 * @return number of nodes in tree
	 */
	int countNodes() {
		if(root == null) {
			return 0;
		}else {
			return count(root);
		}
	}
	
	/**
	 * Helper method for countNodes and getHeight.
	 * @param node node at which all of the values should be counted.
	 * @return number of nodes attached to node. 
	 */
	private int count(Node<E> node) {
		//If the node has any children, the recursion should continue counting more of the nodes
		if(node != null && node.hasChildren()) {
			if(node.hasLeft() && node.hasRight()){
				return (1 + count(node.getLeft())) + (count(node.getRight()));
			}else if(node.hasLeft()){
				return 1 + count(node.getLeft());
			}else{
				return 1 + count(node.getRight());
			}
		}else {
			return 1;
		}
	}
	
	/**
	 * Count number of leaf nodes in tree
	 * @return number of leaf nodes
	 */
	int countLeafNodes() {
		if(root == null) {
			return 0;
		}else {
			return countLeaves(root);
		}
	}
	
	/**
	 * Helper method for countLeafNodes
	 * @param node node for recursive function
	 * @return number of leaves
	 */
	private int countLeaves(Node<E> node) {
		if(node != null && node.hasChildren()) {
			if(node.hasLeft() && node.hasRight()){
				return (countLeaves(node.getLeft())) + (countLeaves(node.getRight()));
			}else if(node.hasLeft()){
				return countLeaves(node.getLeft());
			}else{
				return countLeaves(node.getRight());
			}
		}else if(node == null){
			return 0;
		}else {
			return 1;
		}
	}
	
	/**
	 * Returns how many steps it takes to get from the root of the tree to the farthest node.
	 * See below for one lined version
	 * @return height of BST
	 */
	int getHeight() {
		return heightHelper(root);
	}
	
	/**
	 * Helper for getHeight
	 * @param node node to get height at (for recursion).
	 * @return height
	 */
	private int heightHelper(Node<E> node){
        if (node == null)
            return -1;
        else
        {
            /* compute the depth of each subtree */
            int leftHeight = heightHelper(node.getLeft());
            int rightHeight = heightHelper(node.getRight());
  
            /* use the larger one */
            return leftHeight >= rightHeight ? (1 + leftHeight) : (1 + rightHeight);
        }
	}
	
	/**
	 * Prints elements in "in order".
	 */
	public void printInorder() {
		if (root == null)
			return;
		else
			printInorder(root);
	}

	/**
	 * Helper method for printInorder
	 * @param temp node for recursion
	 */
	private void printInorder(Node<E> temp) {
		if (temp.getLeft() != null) {
			printInorder(temp.getLeft());
		}
		System.out.print(temp.getData() + " ");
		if (temp.getRight() != null) {
			printInorder(temp.getRight());
		}
	}

	/**
	 * Prints elements in "pre order".
	 */
	public void printPreorder() {
		if (root == null)
			return;
		else
			printPreorder(root);
	}

	/**
	 * Helper method for printPreoder
	 * @param temp node for recursion
	 */
	private void printPreorder(Node<E> temp) {
		System.out.print(temp.getData() + " ");
		if (temp.getLeft() != null) {
			printPreorder(temp.getLeft());
		}
		if (temp.getRight() != null) {
			printPreorder(temp.getRight());
		}
	}

	/**
	 * Print elements in "post order"
	 */
	public void printPostorder() {
		if (root == null)
			return;
		else
			printPostorder(root);
	}

	/**
	 * Helper method for printPostorder.
	 * @param temp node for recursion
	 */
	private void printPostorder(Node<E> temp) {
		if (temp.getLeft() != null) {
			printPreorder(temp.getLeft());
		}
		if (temp.getRight() != null) {
			printPreorder(temp.getRight());
		}
		System.out.print(temp.getData() + " ");
	}

	
}
