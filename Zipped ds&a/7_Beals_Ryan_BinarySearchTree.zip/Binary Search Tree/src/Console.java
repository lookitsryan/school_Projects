import java.io.File;
import java.io.FileNotFoundException;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Console {

	public static void main(String[] args) {
		BST tree = new BST();
		Scanner reader = new Scanner(System.in);
		int input = 0;
		while(reader(input, tree)) {
			System.out.println("Options for this program: \n(1)  Add values from a file to the tree \n(2)  Add values to a tree \n(3)  See if a tree contains a value "
					+ "\n(4)  Delete a value from a tree \n(5)  Test traversals (pre, in, post) \n(6)  Print stats (nodes, leaf nodes, height) \n(7)  Clear the tree "
					+ "\n(8)  Exit program");
			System.out.println("Please type an integer from 1-8 to select an option.");
			try {
				input = reader.nextInt();
			}catch(InputMismatchException e) {
				System.out.println("Invalid input, please type an integer from 1-8.");
				input = 0;
			}
		}
	}
	
	/**
	 * 
	 */
	static boolean reader(int input, BST tree) {
		Scanner in = new Scanner(System.in);
		switch(input) { //Reads the input from console and 
		case 0 :
			return true;
		case 1 :
			System.out.println("Please input file name");
			try{
				String name = in.next();
				File file = new File(name);
				Scanner fileScanner = new Scanner(file);
				while(fileScanner.hasNextLine()){
					int toAdd = fileScanner.nextInt();
					tree.add(toAdd);
				}
			}catch(FileNotFoundException e){
				System.out.println("File not found, please check the spelling of the name.");
			}
			System.out.println("File added, press enter to continue.");
			in.nextLine();
			in.nextLine();
			return true;
		case 2 :
			System.out.println("Please enter a value to be added to the tree.");
			tree.add(in.nextInt());
			System.out.println("Element added, press enter to continue.");
			in.nextLine();
			in.nextLine();
			return true;
		case 3 :
			System.out.println("Please enter the value to be searched for in the tree.");
			int value = in.nextInt();
			if(tree.contains(value)){
				System.out.println("The tree contains the value " + value + ".");
			}else{
				System.out.println("The tree does contain not the value " + value + ".");
			}
			System.out.println("Press enter to continue.");
			in.nextLine();
			in.nextLine();
			return true;
		case 4 :
			System.out.println("Please enter the value to be deleted from the tree.");
			int value1 = in.nextInt();
			if(tree.delete(value1)){
				System.out.println("Value deleted successfully.");
			}else{
				System.out.println("Value not found in tree.");
			}
			System.out.println("Element deleted, press enter to continue.");
			in.nextLine();
			in.nextLine();
			return true;
		case 5 :
			System.out.println("Pre-order: ");
			tree.printPreorder();
			System.out.println();
			System.out.println("In-order: ");
			tree.printInorder();
			System.out.println();
			System.out.println("Post-order: ");
			tree.printPostorder();
			System.out.println();
			System.out.println("Press enter to continue.");
			in.nextLine();
			in.nextLine();
			return true;
		case 6 :
			System.out.println("Number of Nodes: " + tree.countNodes());
			System.out.println("Number of Leaf Nodes: " + tree.countLeafNodes());
			System.out.println("Height: " + tree.getHeight());
			System.out.println("Press enter to continue.");
			in.nextLine();
			in.nextLine();
			return true;
		case 7 :
			System.out.println("Clearing tree...");
			tree.delete();
			System.out.println("Tree cleared, press enter to continue.");
			in.nextLine();
			in.nextLine();
			return true;
		case 8 :
			System.out.println("Exiting program.");
			return false;
		}
		System.out.println("Invalid input, please type an integer from 1-8.");
		System.out.println("Press enter to continue.");
		in.nextLine();
		in.nextLine();
		return true;
	}
}
