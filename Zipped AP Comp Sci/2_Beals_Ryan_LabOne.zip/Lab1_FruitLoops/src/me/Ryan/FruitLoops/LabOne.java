package me.Ryan.FruitLoops;



public class LabOne {

	public static void main(String[] args) {
		LabOne testThing = new LabOne();
		//System.out.println(testThing.sumOdds(11));
		LabOne test = new LabOne();
		//System.out.println(test.numTails(10));
		//System.out.println(test.piApprox(100000));
		System.out.println(test.countRolls(3, 2));
	}
	public int sumOdds(int x){
		int sum = 0;
		for(int i = 1; i <= x; i++){
			if(i % 2 == 1){
				sum+=i;
			}
		}
		
		return sum; //Placeholder
	}
	public double piApprox(int x){
		double denom = 1;
		double pi = 0;
		for(int i = 0; i < x; i++){
			if(i % 2 == 0){
				pi += 4/denom;
			}else{
				pi -= 4/denom;
			}
			denom += 2;
		}
		return pi;
	}
	public int numTails(int x){
		int numTails = 0;
		for(int i = 0; i < x; i++){
			int tails = (int)(Math.random()*2);
			if(tails==0){
				numTails++;
			}
		}
		return numTails;
	}
	public int countRolls(int x, int y){
		int numRolls = 0;
		int numCorrectRolls = 0;
		boolean isRolling = true;
		if(x > 6 || x < 1){
			return -1;
		}
		while(numCorrectRolls < y){
			int die = (int)((Math.random() * 6) +1);
			if(die == x){
				numCorrectRolls++;
			}
			numRolls++;	
		}
		return numRolls;
	}
	
}
