import gpdraw.*;

import java.awt.Color;
import java.lang.Object.*;
public class Fractals {//I tried my best
	//Also sorry this is late, I had it done but totally forgot :(
	static int level = 0;
	SketchPad s = new SketchPad(1000, 1000);
	DrawingTool d = new DrawingTool(s);
	
	public static void main(String[] args) {
		Fractals tester = new Fractals();
		//tester.snowflake(300);
		//tester.squares(300);
		tester.drawSquares(6, 300);
	}
	public void snowflake(int length){//Calling method to reduce clutter in main
		d.home();
		d.turn(270);
		d.up();
		d.backward(length/2);
		drawKochSnowflake(6, length);
	}
	public void kochCurve(double lvl, double len){
		if(lvl< 1){
			d.down();
			d.forward(len);
		}
		else{
			kochCurve(lvl - 1, (len)/3);
			d.turn(60);
			kochCurve(lvl - 1, (len)/3);
			d.turn(240);
			kochCurve(lvl - 1, (len)/3);
			d.turn(60);
			kochCurve(lvl - 1, (len)/3);
		}
	}
	public void drawKochSnowflake(int lvl, double len){
		d.turn(180);
		d.backward(len/2);
		kochCurve(lvl, len);
		d.turn(240);
		kochCurve(lvl, len);
		d.turn(240);
		kochCurve(lvl, len);
	}
	public void squares(int length){//Calling method for squares
		d.home();
		d.up();
		d.forward(length*19/20);
		d.turn(270);
		d.backward(length*19/20);
		allSquares(6, length);
	}
	public void drawSquares(int lvl, double len){
		if(lvl < 1){
			d.down();
			d.forward(len);
		}else{
			drawSquares(lvl - 1, (len)/1.5);
			d.turn(90);
			drawSquares(lvl - 1, (len)/1.5);
		}
	}
	public void allSquares(int lvl, double len){
		d.turn(180);
		d.backward(len/2);
		drawSquares(lvl, len);
		d.turn(240);
		drawSquares(lvl, len);
		d.turn(240);
		drawSquares(lvl, len);
	}

}