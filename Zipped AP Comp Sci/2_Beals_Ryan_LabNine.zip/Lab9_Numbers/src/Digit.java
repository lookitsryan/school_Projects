public class Digit {
	private int number;
	private String nums = "123456789ABCDEFG";
	private int base;
	public Digit(int num){
		number = num;
//		inBase += num;
		base = 10;
	}
	public Digit(int num, int b){
		number = num;
//		inBase += num;
		base = b;
	}
	public int toBase(){
		int sum = 0;
		int count = 0;
		int num1 = number;
		while(num1 > 0){
			int num2 = num1%10;
			sum += num2*(Math.pow(base, count));
			num1/=10;
			count++;
		}
		return sum;
	}
	public String toString(){
		String numP = "";
		int fNum = 0;
		int num2 = number;
		if(base > 10){
			numP += nums.charAt(base);
			num2-=base;
			numP += num2;
		}
		if(base != 10){
			int count = 0;
			while(num2 > 0){
				int num1 = num2%10;
				fNum += num1*(Math.pow(base, count));
				System.out.println(fNum);
				num2/=10;
				count++;
			}
		}
		numP += fNum;
		return numP;
	}
	public boolean Increment(){
		boolean resets = false;
		if(number+1 > base-1){
			number = 0;
			resets = true;
		}
		number+=1;
		return resets;
	}
}
