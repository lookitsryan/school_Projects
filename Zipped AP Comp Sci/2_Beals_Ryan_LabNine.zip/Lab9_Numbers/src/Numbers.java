import java.util.Scanner;
public class Numbers {
	
	public static void main(String[] args) {
		Scanner reader = new Scanner(System.in);
		System.out.println("Please input a base 10 value to be converted");//asks for value
		int num = reader.nextInt();
		System.out.println("Please input the base to be converted to");
		int base = reader.nextInt();
		Digit digit = new Digit(num, base);//Makes new digit
		System.out.println(digit.toBase());
	}
	
}
