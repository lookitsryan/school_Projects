import java.util.ArrayList;

public class Number {
	private ArrayList<Digit> num = new ArrayList<Digit>();
	int number;
	int base;
	public Number(int n){
		base = 10;
		number = n;
		while(number > 0){
			Digit num1 = new Digit(number%10, base);
			num.add(num1);
			number/=10;
		}
	}
	public Number(int n, int b){
		base = b;
		number = n;
		while(number > 0){
			Digit num1 = new Digit(number%10, base);
			num.add(num1);
			number/=10;
		}
	}
	public void Increment(){//Couldn't set up an addition method for digit :(
//		num.get(0).Increment();
//		Digit n = new Digit(num.get(0), 10)
//		num.set(0, num.get(0)+1);
	}
	public String toString(){
		String numP = "";
		for(int i = num.size(); i > 0; i++){
			numP += num.get(i);
		}
		return numP;
	}
}
