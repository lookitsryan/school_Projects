import java.util.*;
import info.gridworld.actor.*;
import info.gridworld.actor.ActorWorld;
import info.gridworld.grid.Location;
public class GridWorldRunner {

	public static void main(String[] args) {
		ActorWorld world = new ActorWorld();
		world.add(new Flower());
		BashfulCritter b = new BashfulCritter(5);
		world.add(b);
		world.add(new Rock());
		world.show();
	}

}
