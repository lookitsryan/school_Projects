import java.util.ArrayList;
import java.awt.Color;
import info.gridworld.actor.Actor;
import info.gridworld.actor.Critter;
import info.gridworld.grid.Location;
public class BashfulCritter extends Critter{
	private int c;
	public BashfulCritter(int c){
		this.c = c;
	}
	/**
	 * Gets actors within 2 units
	 */
	@Override
	public ArrayList<Actor> getActors(){
		ArrayList<Actor> actors = new ArrayList<Actor>();
		for(int angle = 0; angle <= 360; angle+=45){ //Within 1 square
			Location loc = this.getLocation().getAdjacentLocation(this.getDirection() + angle);
			int dir = this.getLocation().getDirectionToward(loc);
			Location newLoc = loc.getAdjacentLocation(dir);
			if(this.getGrid().isValid(loc)){
				if(this.getGrid().get(loc) instanceof Critter)
			    	actors.add(this.getGrid().get(loc));
			}else if(this.getGrid().isValid(newLoc)){
				if(this.getGrid().get(newLoc) instanceof Critter)
			    	actors.add(this.getGrid().get(newLoc));
			}
		}
		return actors;
	}
	/**
	 * Changes color depending on courage
	 */
	@Override
	public void processActors(ArrayList<Actor> actors){
		if(c < actors.size()){
			this.setColor(this.getColor().darker());
		}
		if(c > actors.size()){
			this.setColor(this.getColor().brighter());
		}
	}
	
}
