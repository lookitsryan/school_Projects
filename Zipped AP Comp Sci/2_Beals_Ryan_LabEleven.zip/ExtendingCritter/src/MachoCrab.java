import java.util.ArrayList;
import info.gridworld.actor.Actor;
import info.gridworld.actor.Rock;
import info.gridworld.grid.Location;
/**
 * MachoCrab is more macho than anything around it, so it will push them back or eat them! Unless it's a rock, rocks cause indigestion
 * 
 * @author Ryan Beals
 *
 */
public class MachoCrab extends CrabCritter {
	/**
	 * MachoCrab must look at the actors in front of it before pushing them back
	 * 
	 * @param actors ArrayList of actors around the crab
	 */
	@Override
	public void processActors(ArrayList<Actor> actors){
		for(Actor a : actors){
			Location loc = a.getLocation();
			int dir = this.getLocation().getDirectionToward(loc);
			Location newLoc = loc.getAdjacentLocation(dir);
			if(this.getGrid().isValid(newLoc) && !(this.getGrid().get(newLoc) instanceof Rock)){
				a.moveTo(newLoc);
			}else if(a instanceof Rock && !(this.getGrid().isValid(newLoc))){
				//do nothing again
			}else if(a instanceof Rock && this.getGrid().get(newLoc) instanceof Rock){
				//do nothing
			}else{
				a.removeSelfFromGrid();
			}
		}
	}
}
