import java.util.ArrayList;

import info.gridworld.actor.*;
/**
 * HippieCritter loves flowers so whenever it is next to one or many, it will steal them all!
 * 
 * @author Ryan Beals
 *
 */
public class HippieCritter extends Critter{
	/**
	 * Hippies love flowers, so these critters "steal" all flowers to the side of them
	 * 
	 * @param actors List of actors around the critter
	 */
	@Override
	public void processActors(ArrayList<Actor> actors){
		for(Actor a : actors){
			if(a instanceof Flower)
				a.removeSelfFromGrid();
		}
	}
}
