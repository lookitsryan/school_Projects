/**
 * A class that represents an item from a store. Contains an 
 * id number and inventory (the # of items left in the store)
 * 
 * @author 
 */
public class Item implements Comparable<Item>{
	/**
	 * ID number for the item (each is unique)
	 */
	private int myId;

	/**
	 * Number of items left in the store
	 */
	private int myInv;

	/**
	 * Creates an item with a specific id and inventory
	 * @param id - the unique ID number for this item
	 * @param inv - the number of this item in stock
	 */
	public Item(int id, int inv){
		myId = id;
		myInv = inv;
	}

	/**
	 * Returns the ID number
	 * @return the ID number for this item
	 */
	public int getId(){ 
		return this.myId; 
	}

	/**
	 * Returns the number of this item in store
	 * @return the number of items in the store
	 */
	public int getInv(){
		return this.myInv;
	}

	/**
	 * Returns a negative number when the calling item
	 * is before the argument item (according to ID number),
	 * 0 if the IDs are the same, and a positive number otherwise
	 * @param other the item to compare this item to
	 */
	public int compareTo(Item other){ 
		if(this.getId() < other.getId()){
			return -1;
		}else if(this.getId() > other.getId()){
			return 1;
		}else if(this.getId() == other.getId()){
			return 0;
		}
		return -1;
	}

	/**
	 * Returns whether these items are the same or not (ID numbers)
	 * @param other the item to compare to 
	 * @return true if the items have the same ID number, false if not
	 */
	public boolean equals(Item other){ 
		if(this.getId() == other.getId()){
			return true;
		}else{
			return false;
		}
	}

	/**
	 * Returns the String representation of this item
	 */
	public String toString(){
		return "ID: " + this.getId() + "Inv: " + this.getInv() + " [ITEM]";
	}
}
