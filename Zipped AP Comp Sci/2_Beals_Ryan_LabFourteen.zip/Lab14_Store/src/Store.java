import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;
/**
 * A class that represents a Store containing
 * some set of items
 * 
 * @author 
 */
public class Store{
	
	/**
	 * List of Item objects; represents the items currently 
	 * present in this store
	 */
	private ArrayList<Item> myStore;

	/**
	 * Creates a store with the items lists in the given file
	 * @param fName the name of the file containing the items of the store
	 */
	public Store(String fName){ 
		myStore = new ArrayList<Item>();
		loadFile(fName);
	}

	/**
	 * Creates a store with the items in the file "file50.txt"
	 */
	public Store(){
		myStore = new ArrayList<Item>();
		loadFile("file50.txt");
	}

	/**
	 * Loads the store with the elements in the given file
	 * @param inFileName the file to be read that contains the items in the store
	 */
	private void loadFile(String inFileName){ 
		try{
			File file = new File(inFileName);
			Scanner input = new Scanner(file);
			while(input.hasNextInt()){
				this.myStore.add(new Item(input.nextInt(), input.nextInt()));
			}
		}catch(FileNotFoundException e){
			System.out.println("File not found");
		}
	}

	/**
	 * Display each item the store with the given format: 
	 * Number		ID Number		Inventory
	 * #			#				#
	 * For readability, an empty line appears every 10 items
	 * and list is shown in lined-up columns
	 */
	public void displayStore(){
		System.out.println(this);
	}

	/**
	 * Returns the String representation of this store (see description for displayStore)
	 */
	public String toString(){
		String a = String.format("Number %11s%14s", "ID Number", "Inventory");
		int format = 13;
		int format2 = 11;
		for(int i = 0; i < this.myStore.size(); i++){
			if(i % 10 == 0){
				a += "\n";
			}
			int n = i+1;
			if(n == 10){
				format--;
			}
			a += "\n" + String.format(n + "%" + format + "s%" + format2 + "s", this.myStore.get(i).getId(), this.myStore.get(i).getInv());
		}
		return a;
	}  

	/**
	 * Sorts the store by ID number
	 */
	public void sort(){
		mergesort(this.myStore, 0, this.myStore.size() - 1);
	}	

	/**
	 * Merge two sublists of Items
	 * @param a	the list containing the two sublists
	 * @param first index of first element
	 * @param mid	index of middle element
	 * @param last	index of last element
	 */
	@SuppressWarnings("rawtypes")
	public static void merge(ArrayList<Item> list, int first, int sec, int last){
		int indF = first; //Index of start of first half
		int indS = sec; //Index of start of second half
		ArrayList<Comparable> temp = new ArrayList<Comparable>();
		while(indF < sec && indS <= last){ //While there are elements in each half of the list
			if(list.get(indF).compareTo(list.get(indS)) < 0){ //< = Ascending/ > = descending
				temp.add(list.get(indF));
				indF++;
			}else{
				temp.add(list.get(indS));
				indS++;
			}
		}
		if(indF < sec){//If there are elements in the left side of the ArrayList but not the right
			for(int i = indF; i < sec; i++){
				temp.add(list.get(i));
			}
		}
		else if(indS <= last){//If there are elements in the right side of the ArrayList but not the left
			for(int i = indS; i <= last; i++){
				temp.add(list.get(i));
			}
		}
		for(int i = first; i <= last; i++){//Fill original ArrayList
			list.set(i, (Item) temp.remove(0));
		}
	}
	

	/**
	 * Mergesort the list of items
	 * @param a the list containing all the items to be sorted
	 * @param first the index of the first element in the list to be sorted
	 * @param last the index of the last element in the list to be sorted
	 */
	private void mergesort(ArrayList<Item> list, int first, int last){ 
		if(first < last){
			int mid = (first+last)/2;
			mergesort(list, first, mid);
			mergesort(list, mid+1, last);
			merge(list, first, mid + 1, last);
		}else
			return;
	}
	public void testSearch(){
		int idToFind;
		int invReturn;
		int index;
		Scanner in = new Scanner(System.in);
		
		System.out.println("Testing search algorithm\n");
		do{
			System.out.println();
			System.out.print("Enter Id value to search for (-1 to quit) ---> ");
			idToFind = in.nextInt();
			index = bsearch(new Item(idToFind, 0));
			//recursive version call
			//index = bsearch(new Item(idToFind, 0), 0, this.myStore.size()-1);
			System.out.print("Id # " + idToFind);
			if(index == -1){
				System.out.println("    No such part in stock");
			}else{
				System.out.println("    Inventory = " + this.myStore.get(index).getInv());
			}
		}while(idToFind >= 0);
	}
	
	/**
	 * Searches the myStore ArrayList of Item Objects for the specified
	 * item object using an iterative binary search algorithm
	 *  
	 * @param idToSearch     Item object containing id value being searched for
	 * @return               index of Item if found, -1 if not found
	 */
	private int bsearch(Item idToSearch){
		int low = 0;
		int high = this.myStore.size()-1;
		while(low <= high){
			if(this.myStore.get(low).getId() == idToSearch.getId()){
				return low;
			}
			low++;
		}
		return -1;
	}
	
	/**
	 * Searches the myStore ArrayList of Item Objects for the specified
	 * id using a recursive binary search algorithm
	 * 
	 * @param idToSearch     Item object containing id value being searched for
	 * @param first          Starting index of search range
	 * @param last           Ending index of search range
	 * @return               index of Item if found, -1 if not found
	 */
	private int bsearch(Item idToSearch, int first, int last){
        if(first > last){ //id doesn't exist
            return -1;
        }
        int mid = (first + last) / 2;
        if(this.myStore.get(mid).equals(idToSearch)){
            return mid;
        }else if(this.myStore.get(mid).getId() > idToSearch.getId()){
            return bsearch(idToSearch, first, mid - 1);
        }else{ //mid < idToSearch
            return bsearch(idToSearch, mid + 1, last);
        }
	}

}
