
public class Runner {

	public static void main(String[] args) {
		Store store = new Store("file50.txt");
		store.sort();
		System.out.println(store);
		store.testSearch();
	}

}
