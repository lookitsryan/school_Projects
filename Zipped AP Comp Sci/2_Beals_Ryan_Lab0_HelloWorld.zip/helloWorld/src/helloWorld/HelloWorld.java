package helloWorld;

public class HelloWorld {
	//Main method: where every java program executes lines of code
	public static void main(String[] args){
		System.out.println("Hello, world!");
	}
	
}
