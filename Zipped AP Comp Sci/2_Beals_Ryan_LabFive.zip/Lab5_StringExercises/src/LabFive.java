
public class LabFive {

	public static void main(String[] args) {
		
	}
	public static String reverse(String str){
		String s = "";
		for(int i = str.length(); i > 0; i--){
			char c = str.charAt(i-1);
			s+=c;
		}
		return s;
	}
    public static String removeAll(String str, String s){
		while(str.indexOf(s) > -1){//While "str" still contains "s"
			int a = str.indexOf(s);//Find the next "s"
			String b = str.substring(0, a);//String before "s"
			str = b += str.substring(a+s.length(), str.length());//String after "s"
		}
		return str;
	}
    public static boolean isPalindrome(String str){
    	for(int i = 32; i <= 127; i++){//Checking for non-letter values
    		if((i >= 48 && i <= 57) || (i >=65 && i <= 90) || (i >=97 && i <= 122)){//ditto
    			continue;
    		}
    		char a = (char) i;
    		String b = "" + a;
    		str = removeAll(str, b);
    	}
    	if(str.equalsIgnoreCase(reverse(str))){
    		return true;
    	}
    	return false;
    }
    public static String toPigLatin(String str){
    	str.trim();
    	int lastChar = 0;
    	String s = "";
    	for(int i = 0; i < str.length(); i++){
    		if((int)str.charAt(i) == 32 || i == str.length() - 1){
    			int ch = i;
    			if(i == str.length() - 1){
    				ch+=1;
    			}
    			String a = vowel(str.substring(lastChar, ch));
    			lastChar = ch+1;
    			s = s+=a+=" ";
    		}
    	}
    	return s;
    }
    public static String vowel(String str){
    	int ch = 0;
    	if(str.contains("a") || str.contains("e") || str.contains("i") || str.contains("o") || str.contains("u") || str.contains("A")
    			|| str.contains("I")){
			if(str.charAt(0) == 'a' || str.charAt(0) == 'e' || str.charAt(0) == 'i' || str.charAt(0) == 'o' || str.charAt(0) == 'u'
					|| str.charAt(0) == 'A' || str.charAt(0) == 'I'){
				return str += "yay";
			}else{
				for(int i = 0; i < str.length(); i++){
					if(str.charAt(i) == 'a' || str.charAt(i) == 'e' || str.charAt(i) == 'i' || str.charAt(i) == 'o' || str.charAt(i) == 'u'){
						ch = i;
						break;
					}
				}
				String a = str.substring(0, ch);
				String b = str.substring(ch, str.length());
				return b += a += "ay";
			}
		}else{
			return str += "ay";
		}
    }

}
