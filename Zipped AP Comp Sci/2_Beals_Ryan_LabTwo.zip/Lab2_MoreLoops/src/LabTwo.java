
public class LabTwo {//By: Ryan Beals

	public static void main(String[] args) {
		LabTwo tester = new LabTwo();
	}
	public void starPyramid(int rows){
		int spaces = rows-1;
		for(int i = 0; i <= rows * 2; i++){
			if(i % 2 == 1){
			    for(int a = 0; a <= spaces; a++){
					System.out.print(" ");
			    }
			    for(int j = 0; j < i; j++){
				    System.out.print("*");
			    }
			    spaces--;
				System.out.println(" ");
			}
		}
			
			
	}
	public void printChart(int num){
		int pnum = 1;
		int max = num;
		for(int j = 1; j <=num; j++){
		    for(int i = 1; i <=j; i++){
		    	if(pnum <= max){
		    		System.out.print(pnum + " ");
		    		pnum++;
		    	}
		    	
		    }
		    System.out.println("");
		}
		
	}
	public void armstrongNumbers(int min, int max){
		for(int i = min; i <=max; i++){
			if(isArmstrong(i)){
				System.out.println(i);
			}
		}
		
	}
	public int numDigits(int num){
		int digits = 0;
		int x = num;
		for(int i = 1; i > 0; i++){
			if(x>0){
				x/=10;
				digits++;
			}
			else if(num==0){
				return 1;
			}
			else{
				return digits;
			}
		}
		return 0;
	}
	public int power(int base, int exp){
		int x = 1;
		for(int i = 0; i < exp; i++){
			x*=base;
		}
		return x;
	}
	public boolean isArmstrong(int num){
		int x = numDigits(num);
		int a = num;
		int sum = 0;
		for(int i = 0; i < x; i++){
			int y = a%10;
			a=a/10;
			sum += power(y, x);
		}
		if(sum == num){
			return true;
		}
		return false;
	}

}
