import info.gridworld.actor.*;
public class ZBug extends Bug{
	private int steps = 0;
	private int count = 0;
	private int x = 0;
	public ZBug(int num){
		steps = num;
		this.setDirection(90);
	}
	public void act(){
		if(steps == count){
			if(x == 0){
				turn();
				turn();
				turn();
			}
			if(x == 1){
				this.setDirection(90);
			}
			count = 0;
			x++;
		}
		if(canMove()){
			if(x >= 3){
				
			}else{
				move();
				count++;
			}
		}else{
			turn();
		}
	}

}
