import info.gridworld.actor.Bug;
public class SpiralBug extends Bug{
	private int steps = 0;
	private int count = 0;
	public SpiralBug(int num){
		steps = num;
	}
	public void act(){
		if(steps == count){
			turn();
			turn();
			steps++;
			count = 0;
		}
		if(canMove()){
			move();
			count++;
		}else{
			turn();
		}
	}
}
