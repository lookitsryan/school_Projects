import info.gridworld.actor.*;
public class DancingBug extends Bug{
	private int[] steps;
	private int count = 0;
	public DancingBug(int[] nums){
		steps = nums;
	}
	public void act(){
		if(count == steps.length){
			count = 0;
		}
		for(int i = 0; i < steps[count]; i++){
			turn();
		}
		move();
		count++;
	}
}
