import info.gridworld.world.*;
import info.gridworld.actor.*;
import info.gridworld.grid.*;
public class BugRunner {

	public static void main(String[] args) {
		int[] steps = new int[4];
		steps[0] = 3; steps[1] = 3; steps[2] = 2; steps[3] = 1;
		@SuppressWarnings("rawtypes")
		UnboundedGrid grid = new UnboundedGrid();
		ActorWorld world = new ActorWorld(grid);
		DancingBug bug = new DancingBug(steps);
		ZBug bug1 = new ZBug(4);
		world.add(new Location(15, 15), bug);
		world.add(new Location(20, 20), bug1);
		world.show();
	}

}
