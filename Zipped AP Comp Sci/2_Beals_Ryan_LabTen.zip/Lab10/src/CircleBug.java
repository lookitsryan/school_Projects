import info.gridworld.actor.Bug;
public class CircleBug extends Bug {
	private int steps = 0;
	private int count = 0;
	public CircleBug(int num){
		steps = num;
	}
	public void act(){
		if(count == steps){
			count = 0;
			turn();
		}
		if(canMove()){
			move();
			count++;
		}else{
			turn();
		}
	}
}
