import java.io.*;
import java.util.Scanner;
public class Statistics {
	private int nums[] = new int[101];//Creates array containing number of numbers given (if there are 10 6's, then 6 in the array has a value of 10)
	public static void main(String[] args) {
		Statistics tester = new Statistics("numbers.txt");
		tester.displayStats();
	}
	public Statistics(String s){
		try{//Try-catch FileNotFound
			File file = new File(s);
			Scanner reader = new Scanner(file);//Reads file
			while(reader.hasNextInt()){
				int num = reader.nextInt();
				nums[num] = nums[num]+1;
			}
		}catch(FileNotFoundException e){
			System.out.println("This file cannot be found..");
		}
	}
	public void displayStats(){//Prints average, standard deviation, and mode of given text file
		System.out.printf("%.1f\n", average());
		System.out.printf("%.1f\n", standardDev());
		System.out.println(mode());
	}
	public double average(){//Calculates average
		double sum = 0;
		double totalNum = 0;
		for(int i = 0; i < nums.length; i++){
			for(int j = 0; j < nums[i]; j++){
				sum += i;
				totalNum++;
			}
		}
		return sum/totalNum;
	}
	public double standardDev(){//Calculates standard deviation
		int sum = 0;
		int totalNum = 0;
		double avg = average();
		for(int i = 0; i < nums.length; i++){
			for(int j = 0; j < nums[i]; j++){
				sum += ((i-avg)*(i-avg));
				totalNum++;
			}
		}
		int x = sum/(totalNum-1);
		return Math.sqrt(x);
	}
	public String mode(){//Finds most often number(s)
		int mo = 0;
		String modesStr = "";//String to hold all modes
		int[] modes = new int[nums.length];//Array to hold modes (length of nums just to be safe)
		for(int i = 0; i < nums.length; i++){//Finds lowest mode
			if(nums[i] > nums[mo])
				mo = i;
		}
		for(int j = 0; j < nums.length; j++){//Assigns "modes" array values of most often numbers
			if(nums[j] == nums[mo])
				modes[j] = j;
		}
		for(int k = 0; k < modes.length; k++){//Modes given to "modesStr" String
			if(mo != 0 && modes[k] == 0)
				continue;
			modesStr += modes[k] + " ";
		}
		return modesStr;//Returns all modes
	}

}
