
public class Sorts {
    /**
     * Method to quicksort an array using partitioning
     * @param arr Array to quicksort
     */
    public static void quicksort(int[] arr) {
        sortMe(0, arr.length-1, arr);
    }

    /**
     * Recursive helper method for quicksort
     * @param min Starting index at which to sort
     * @param max Ending index at which to sort
     * @param a Array being sorted
     */
    public static void sortMe(int min, int max, int[] a) {
        if(max-min < 1) { //Checks if list is sorted
            return;
        }else { //If list is not fully sorted...
            int newPivot = partition(min, max, a); //Partition given section of array and return pivot
            sortMe(min, newPivot-1, a); //Sort part of array starting at min value and ending at 1 index before pivot
            sortMe(newPivot+1, max, a); //Sort other part of array, starting at 1 index greater than value, ending at max value
        }

    }

    /**
     * Method to sort int[] "a" at pivot a[0]
     * @param min Index to start sorting at, pivot+1
     * @param max Index to end sorting at, inclusive
     * @param a int[] to sort
     * @return Index of pivot
     */
    public static int partition(int min, int max, int[] a) { //Method to sort int[] "a"
        int left = min+1; //Left pointer, one index larger than pivot
        int right = max; //Right pointer, last index in array
        while(left <= right){ //Exits when left pointer passes or is at right pointer
            if(a[left] <= a[min]) { //If pivot is bigger than the value at the left pointer, then move pointer
                left++; //Otherwise, move left pointer up
            }else { //If left pointer has found a value greater than the pivot, start moving right pointer
                if(a[right] >= a[min]) { //Ditto
                    right--; //If value is greater than the pivot, keep it on the right side of the array
                }
                else { //If value is less than pivot, stop moving the right pointer and swap values at left and right
                    swap(right, left, a);
                }
            }
        }
        if(a[min] > a[left-1]){
        	swap(min, left-1, a); //Swap pivot and the value before the left pointer
        }
        return left-1; //Return index of pivot
    }
    
    /**
     * Method to swap values in an array
     * @param x Index of first value
     * @param y Index of second value
     * @param a Array containing both values
     */
    public static void swap(int x, int y, int[] a){
        int temp = a[x]; //Temp for first value
        a[x] = a[y]; //Swap first value with second value
        a[y] = temp; //Put first value in second value
    }
}
