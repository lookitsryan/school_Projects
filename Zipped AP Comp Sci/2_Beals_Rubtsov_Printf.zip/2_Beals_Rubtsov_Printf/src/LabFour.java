import java.util.Scanner;
//Ryan Beals and Eric Rubtsov
public class LabFour {
	static Scanner input = new Scanner(System.in);
	public static void main(String[] args) {
		console();
	}
	public static void quadAndLog(int n){
		System.out.printf("n %10s%12s", "n*n", "n*log(n)");
		System.out.printf("\n- %10s%12s", "---", "--------	");
		for(int i = 1; i <= n; i++){
			System.out.printf("\n%d%11d%12.4f", i, i*i, i*Math.log(i));
		}
	}
	public static void multiplicationTable(int a, int b){
		boolean mult = false;
		for(int i = 0; i <= a; i++){
			if(i==0){
				System.out.print(" ");
			}else{
				System.out.print(i);
			}
			for(int j = 1; j <= b; j++){
				if(mult){
					System.out.printf("%5d", j*i);
				}else{
					System.out.printf("%5d", j);
				}
				if(j==b){
					System.out.print("\n");
				}
			}
			mult=true;
		}
	}
	public static void console(){
		boolean noInput = true;
		System.out.println("Which method would you like to run?");
		System.out.println("1. quadAndLog");
		System.out.println("Any other number for multiplicationTable");
		int x = input.nextInt();
		if(x == 1){
			System.out.println("Please enter the number you would like to use");
			int y = input.nextInt();
			quadAndLog(y);
		}
		else{
			System.out.println("Please enter one number you would like to use");
			int a = input.nextInt();
			System.out.println("Please enter the other number you would like to use");
			int b = input.nextInt();
			multiplicationTable(a, b);
		}

	}

}
